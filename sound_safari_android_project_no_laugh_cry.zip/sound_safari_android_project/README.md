# Sound Safari — Android app project

This package contains the Sound Safari game source and a starter setup for building an Android app.

## What is included
- `www/index.html` — the complete game source code.
- `www/manifest.webmanifest`, `www/service-worker.js`, `www/icon.svg` — installable web-app support.
- `package.json` and `capacitor.config.json` — Capacitor 8 project setup for creating an Android app.

## Option A: Install as an app without making an APK (PWA)
1. Upload the entire `www` folder to a secure HTTPS website (for example, your own hosting).
2. Open the website in Chrome on an Android phone or tablet.
3. Open Chrome's menu and choose **Install app** or **Add to Home screen**.
4. Launch Sound Safari from the new home-screen icon. The service worker caches the game for offline play after the first successful load.

A PWA needs to be served from HTTPS (or localhost); opening `index.html` directly from a file manager will not enable installation.

## Option B: Build a real Android APK with Capacitor
You need a computer (Windows, macOS, or Linux), Node.js 22 or newer, and Android Studio (Capacitor 8 currently requires Android Studio 2025.2.1 or newer) with the Android SDK installed.

1. Extract this project ZIP.
2. Open a terminal in the extracted `sound_safari_android_project` folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Create the Android project:
   ```bash
   npx cap add android
   ```
5. Copy the game into the Android project:
   ```bash
   npx cap sync android
   ```
6. Open it in Android Studio:
   ```bash
   npx cap open android
   ```
7. In Android Studio, wait for Gradle sync. Connect an Android phone with USB debugging enabled, or start an emulator.
8. Press **Run** to test it on the device.
9. To create an installable APK, use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
10. Android Studio will show a notification with a link to the generated APK. Copy that APK to the phone and install it. Android may ask you to allow installation from that source.

### For Google Play
For Play Store publication, create a signed Android App Bundle (`.aab`) using **Build → Generate Signed Bundle / APK → Android App Bundle**. You will also need a Play Console developer account, store listing, privacy policy, content rating, and compliance with current Google Play requirements.

## Important notes
- The project contains the synthesized laugh/cry sound effects from the current prototype. They are not genuine recorded baby audio. To use genuine recordings, add licensed audio files and connect them to the game's sound functions.
- The game is currently a web-based game wrapped in an Android app container. It does not yet use native Android game-engine graphics.
- Test on several phone/tablet screen sizes and check sound, touch controls, orientation, pause/resume, and offline launch before publishing.
- The app ID `com.soundsafari.game` is a starter identifier. Change it before publishing if it is already used by another app or if you have a preferred publisher ID.
